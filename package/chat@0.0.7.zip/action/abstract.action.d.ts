import { Input } from "../command";
export declare abstract class AbstractAction {
    protected config(file: string): any;
    abstract handle(inputs?: Input[], options?: Input[], extraFlags?: string[]): Promise<void>;
}
