"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CompressAction = void 0;
const lodash_1 = require("lodash");
const path_1 = require("path");
const fs_1 = require("fs");
const form_data_1 = __importDefault(require("form-data"));
const abstract_action_1 = require("./abstract.action");
const logger_1 = require("../ui/logger");
const file_1 = require("../common/file");
const api_1 = __importDefault(require("../utils/api"));
class CompressAction extends abstract_action_1.AbstractAction {
    zipPackage(packages) {
        return __awaiter(this, void 0, void 0, function* () {
            const dirs = packages
                .map((item) => (Object.assign(Object.assign({}, item), { input: (0, path_1.join)(process.cwd(), item.input), output: (0, path_1.join)(process.cwd(), item.output), json: (0, path_1.join)(process.cwd(), item.json) })))
                .filter((item) => (0, fs_1.statSync)(item.input).isDirectory() &&
                (0, fs_1.statSync)(item.output) &&
                (0, fs_1.statSync)(item.json).isFile());
            const res = yield Promise.all(dirs.map((item) => (0, file_1.zip)(item.name, item.json, item.input, item.output)));
            return res.filter((i) => !!i);
        });
    }
    uploadPackage(name, verions, file) {
        return __awaiter(this, void 0, void 0, function* () {
            const formdata = new form_data_1.default();
            formdata.append("file", (0, fs_1.createReadStream)(file));
            formdata.append("version", verions);
            return api_1.default.put(`/package/update/${name}`, formdata, {
                headers: Object.assign({}, formdata.getHeaders()),
            });
        });
    }
    uploadPackages(packages) {
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.all(packages.map((item) => this.uploadPackage(item.name, item.version, item.file))).then((value) => value.filter((i) => i.code !== 1));
        });
    }
    handle(inputs, options, extraFlags) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const config = (_a = options.find((o) => o.name === "config")) === null || _a === void 0 ? void 0 : _a.value;
            try {
                const configData = this.config(config);
                const pkgs = (0, lodash_1.get)(configData, "packages");
                if (!pkgs || !pkgs.length)
                    return logger_1.Logger.error("配置错误");
                const files = yield this.zipPackage(pkgs);
                if (!files.length)
                    logger_1.Logger.error("压缩失败");
                logger_1.Logger.info("准备上传");
                const [task] = yield this.uploadPackages(files);
                if (task) {
                    logger_1.Logger.error(task.message);
                }
                logger_1.Logger.info("上传资源包完毕");
            }
            catch (error) {
                logger_1.Logger.error(error.message);
            }
        });
    }
}
exports.CompressAction = CompressAction;
