"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginAction = void 0;
const logger_1 = require("../ui/logger");
const api_1 = __importStar(require("../utils/api"));
const abstract_action_1 = require("./abstract.action");
const lodash_1 = require("lodash");
class LoginAction extends abstract_action_1.AbstractAction {
    handle(inputs, options, extraFlags) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            const account = (_a = options.find((o) => o.name === "account")) === null || _a === void 0 ? void 0 : _a.value;
            const password = (_b = options.find((o) => o.name === "password")) === null || _b === void 0 ? void 0 : _b.value;
            if (!account)
                logger_1.Logger.error("请输入账号");
            if (!password)
                logger_1.Logger.error("请输入密码");
            logger_1.Logger.info("开始登录");
            try {
                const data = yield api_1.default.post("/auth/login", { account, password });
                const token = (0, lodash_1.get)(data, "data", "");
                const res = yield api_1.default.post("/auth/credential", undefined, {
                    headers: { authorization: token },
                });
                const credential = (0, lodash_1.get)(res, "data", "");
                (0, api_1.setCredential)(credential);
                logger_1.Logger.info("登录成功");
            }
            catch (error) {
                logger_1.Logger.error("登录异常");
            }
        });
    }
}
exports.LoginAction = LoginAction;
