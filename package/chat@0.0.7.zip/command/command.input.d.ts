export interface Input {
    name: string;
    value: boolean | string;
    options?: any;
}
