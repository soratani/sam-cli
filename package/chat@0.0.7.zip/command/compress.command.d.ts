import { Command } from "commander";
import { AbstractCommand } from "./abstract.command";
export declare class CompressCommand extends AbstractCommand {
    load(program: Command): void;
}
