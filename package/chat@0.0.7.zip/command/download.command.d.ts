import { Command } from "commander";
import { AbstractCommand } from "./abstract.command";
export declare class DownloadCommand extends AbstractCommand {
    load(program: Command): void;
}
