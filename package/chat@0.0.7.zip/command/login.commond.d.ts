import { Command } from "commander";
import { AbstractCommand } from "./abstract.command";
export declare class LoginCommand extends AbstractCommand {
    load(program: Command): void;
}
