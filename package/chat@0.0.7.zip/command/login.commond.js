"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginCommand = void 0;
const lodash_1 = require("lodash");
const abstract_command_1 = require("./abstract.command");
class LoginCommand extends abstract_command_1.AbstractCommand {
    load(program) {
        program
            .command("login")
            .description("登录")
            .option("-a, --account [account]", "账号")
            .option("-p, --password [password]", "密码")
            .action((commond) => __awaiter(this, void 0, void 0, function* () {
            const account = (0, lodash_1.get)(commond, "account");
            const password = (0, lodash_1.get)(commond, "password");
            const inputs = [];
            const options = [];
            options.push({
                name: "account",
                value: account,
            });
            options.push({
                name: "password",
                value: password,
            });
            yield this.action.handle(inputs, options);
        }));
    }
}
exports.LoginCommand = LoginCommand;
