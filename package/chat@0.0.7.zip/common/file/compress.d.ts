export interface IPackage {
    name: string;
    version: string;
    file: string;
}
export declare function zip(name: string, json: string, input: string, output: string): Promise<IPackage>;
