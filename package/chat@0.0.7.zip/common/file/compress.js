"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.zip = void 0;
const fs_1 = require("fs");
const archiver_1 = __importDefault(require("archiver"));
const lodash_1 = require("lodash");
const path_1 = require("path");
const logger_1 = require("../../ui/logger");
function paths(_path, split = "/") {
    return _path.split(split).filter(Boolean);
}
function packageInfo(filepath) {
    const code = (0, fs_1.readFileSync)(filepath).toString();
    try {
        return JSON.parse(code);
    }
    catch (error) {
        return {};
    }
}
function packageName(input) {
    const stat = (0, fs_1.statSync)(input);
    const list = paths(input);
    if (stat.isDirectory()) {
        return list[list.length - 1];
    }
    return list[list.length - 2];
}
function zip(name, json, input, output) {
    const pkgjson = packageInfo(json);
    const version = (0, lodash_1.get)(pkgjson, "version");
    if (!version)
        return;
    const outputPath = (0, path_1.join)(output, `${name}@${version}.zip`);
    const outputStream = (0, fs_1.createWriteStream)(outputPath);
    return new Promise((resolve) => {
        const archive = (0, archiver_1.default)("zip", {
            zlib: { level: 9 },
        });
        outputStream.on("close", function () {
            logger_1.Logger.info(`${name}@${version}.zip ${archive.pointer()} total bytes`);
            logger_1.Logger.info(`${name}压缩完毕`);
            resolve({
                name: name,
                version: version,
                file: outputPath,
            });
        });
        outputStream.on("end", function () {
            logger_1.Logger.info(`${name}压缩完毕`);
        });
        archive.on("warning", function (err) {
            logger_1.Logger.wran(`${name}压缩异常`);
            if (err.code === "ENOENT") {
                resolve(undefined);
            }
            else {
                resolve(undefined);
            }
        });
        archive.on("error", function (err) {
            logger_1.Logger.wran(`${name}压缩异常`);
            resolve(undefined);
        });
        archive.pipe(outputStream);
        return archive.directory(input, false).finalize();
    });
}
exports.zip = zip;
