interface IParams {
    credential: string;
    host?: string;
    [key: string]: any;
}
export default function run(cmd: string, params: IParams): Promise<boolean>;
export {};
