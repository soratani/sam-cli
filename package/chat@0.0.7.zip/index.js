"use strict";
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
const child_process_1 = require("child_process");
const path_1 = require("path");
function run(cmd, params) {
    if (["login", "download", "upload"].includes(cmd))
        return Promise.reject("cmd 错误");
    const { credential, host } = params, _params = __rest(params, ["credential", "host"]);
    const args = Object.entries(_params)
        .filter((item) => !!item[1])
        .reduce((pre, item) => {
        return pre.concat([`--${item[0]}`, item[1]]);
    }, [(0, path_1.join)(__dirname, "cli.js"), cmd]);
    return new Promise((resolve, reject) => {
        (0, child_process_1.execFile)(process.execPath, args, {
            env: { CREDENTIAL: credential, HOST: host },
            cwd: process.cwd(),
            shell: false,
        }, (error, stdout) => {
            if (error) {
                reject(error.message);
            }
            else {
                console.log(stdout);
                resolve(true);
            }
        });
    });
}
exports.default = run;
run("compress", {
    credential: "12323",
    host: "http://127.0.0.1:3000/api",
});
