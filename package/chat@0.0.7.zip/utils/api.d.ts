import axios from "axios";
export declare function fingerprint(): any;
export declare function getCredential(): string;
export declare function setCredential(value: string): void;
export interface IRes {
    code: number;
    message: string;
    data?: any;
}
declare const api: axios.AxiosInstance;
export default api;
