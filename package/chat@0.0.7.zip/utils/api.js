"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.setCredential = exports.getCredential = exports.fingerprint = void 0;
const axios_1 = __importDefault(require("axios"));
const home_1 = __importDefault(require("home"));
const fs_1 = __importDefault(require("fs"));
const lodash_1 = require("lodash");
const os_1 = __importDefault(require("os"));
const md5_1 = __importDefault(require("md5"));
const pkg = require("../../package.json");
function fingerprint() {
    const machine = os_1.default.machine();
    const arch = os_1.default.arch();
    const release = os_1.default.release();
    return (0, md5_1.default)(JSON.stringify({ machine, arch, release }));
}
exports.fingerprint = fingerprint;
function getCredential() {
    const credentialPath = home_1.default.resolve("~/.samrc");
    if (!fs_1.default.existsSync(credentialPath))
        return process.env.CREDENTIAL;
    return (process.env.CREDENTIAL ||
        fs_1.default.readFileSync(credentialPath, { encoding: "utf-8" }));
}
exports.getCredential = getCredential;
function setCredential(value) {
    const credentialPath = home_1.default.resolve("~/.samrc");
    if (!fs_1.default.existsSync(credentialPath)) {
        fs_1.default.mkdirSync(credentialPath);
    }
    return fs_1.default.writeFileSync(credentialPath, value, { encoding: "utf-8" });
}
exports.setCredential = setCredential;
const api = axios_1.default.create({
    baseURL: process.env.HOST,
    headers: {
        version: pkg.version,
        app: pkg.name,
        fingerprint: fingerprint(),
        platform: 4,
        system: 2,
        type: 3,
    },
});
api.interceptors.request.use((config) => {
    return Object.assign(Object.assign({}, config), { headers: Object.assign(Object.assign({}, config.headers), { credential: getCredential() }) });
});
api.interceptors.response.use((value) => {
    return (0, lodash_1.get)(value, "data", { code: 500, message: "服务异常" });
}, (error) => {
    return (0, lodash_1.get)(error, "response.data", { code: 500, message: "服务异常" });
});
exports.default = api;
