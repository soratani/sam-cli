export interface IPkg {
    name: string;
    input: string;
    output: string;
    json: string;
}
export declare function isYaml(file: string): boolean;
export declare function check(config: any): any;
