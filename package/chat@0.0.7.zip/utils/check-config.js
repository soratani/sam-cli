"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.check = exports.isYaml = void 0;
const path_1 = require("path");
const lodash_1 = require("lodash");
const joi_1 = __importStar(require("joi")), joi = joi_1;
const logger_1 = require("../ui/logger");
const IpSchema = joi.object().keys({
    host: joi.string().required(),
    port: joi.alternatives().try(joi.string(), joi.number()).required(),
});
const PkgSchema = joi
    .object()
    .keys({
    name: joi_1.default.string().required(),
    input: joi.string().required(),
    output: joi.string().required(),
    json: joi.string().required(),
})
    .required();
const AssetsSchema = joi.object().keys({
    type: joi
        .array()
        .items(joi.string().valid("cos", "ssh").default("ssh"))
        .required(),
    local: joi.string().required(),
    remote: joi.string().required(),
});
const CosSchema = joi.object().keys({
    type: joi.string().valid("tencent", "ali").default("tencent"),
    region: joi.string().required(),
    bucket: joi.string().required(),
});
const schema = joi.object({
    packages: joi.array().items(PkgSchema),
    ssh: joi.array().ordered(IpSchema),
    cos: CosSchema,
    assets: joi.array().items(AssetsSchema).required(),
});
function isYaml(file) {
    const name = (0, path_1.extname)(file);
    return [".yaml", ".yml"].includes(name);
}
exports.isYaml = isYaml;
function check(config) {
    const { value, error } = schema.validate(config, {
        convert: false,
    });
    const message = (0, lodash_1.get)(error, "details.0.message");
    if (message)
        logger_1.Logger.error(message);
    return value;
}
exports.check = check;
