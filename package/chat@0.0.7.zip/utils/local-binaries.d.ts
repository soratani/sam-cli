import { CommandLoader } from '../command';
export declare function localBinExists(): boolean;
export declare function loadLocalBinCommandLoader(): typeof CommandLoader;
